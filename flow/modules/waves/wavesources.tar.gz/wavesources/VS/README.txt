###### Waves 126, 127, and beyond cannot be real VS waves, since its relevant wave values
###### stop at 125.  These are additional waves drawn from the collection I found at
###### https://www.dropbox.com/sh/ja0tc8wn6cnudzj/AACYqe2mjrWU2CeXIttm6MhOa
###### They may be part of the "additional waves" found in the Korg Wavestation.  
###### John Bowen (!!!) tells me that these waves were likely from a hard drive at 
###### Sequential and didn't make it onto the original VS.  But I'm not positive.

###### Note that there are holes in the remaining range 1...125.  I cannot explain
###### why those waves are missing.
