These are broken up samples from http://www.deepsonic.ch/deep/audio_samples/kawai_k3_-_samples_-_33_waveforms.mp3 by deep!sonic (http://www.deepsonic.ch)

The jpeg image, which contains the names of the waves, is (I believe) taken
from a card which accompanied the K3.  Strangely, the names of the waves do
not appear in either the K3 or K3m manuals.
