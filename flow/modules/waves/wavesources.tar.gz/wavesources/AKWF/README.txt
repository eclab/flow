These are the AdventureKid Waveforms (https://www.adventurekid.se)
They are in the public domain, but you are asked to consider making
a small donation to kristoffer.ekstrand@gmail.com via PayPal.

The stereo samples are zipped because Flow can't load them.
