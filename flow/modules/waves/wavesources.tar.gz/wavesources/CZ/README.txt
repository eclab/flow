The original wave sources on which these harmonics are based are from
the project "Casio CZ-1 Spelunking REMIXED" by John Thompson 
(https://www.facebook.com/Hardwood01) and Michael Rickard 
(https://www.kasploosh.com).  The project home page is
https://www.kasploosh.com/cz/16293-cz_waves_for_your_mix/

You can purchase the wave sources for a mere $10.  I can't distribute
the wave sources but John and Michael have kindly given me permission
to distribute my harmonics as part of Flow, under the provided license.

I include my conversion code to harmonics.
