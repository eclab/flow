These are taken from http://www.buchty.net/ensoniq/files/the_waves.zip by //christian

There are some errors in the wave files:
	digit2 is missing
	formants are in the digit1 and digit2 folders
	glints are missing
	4octs is missing
