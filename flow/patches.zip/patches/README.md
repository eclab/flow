# Flow Patches 

A collection of patches made with Flow.

* **This Directory**  
  Primary patches

* **Experiments** 
  Experimental patches you might find helpful or interesting

* **Macros**  
  Utility patches useful as modules loaded into other patches

* **Percussion**  
  Drum sounds
